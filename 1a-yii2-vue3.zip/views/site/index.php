<?= stripcslashes ($ssr) ?>

